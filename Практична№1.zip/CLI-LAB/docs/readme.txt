AI pipeline: data collection
AI pipeline: cleaning
AI pipeline: feature engineering
test line: experiment-001
AI pipeline: evaluation
