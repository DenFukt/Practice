#!/bin/bash
echo "Мій PID: $$, Мій PPID: $PPID"
ps -p $$ -o pid,ppid,stat,ni,comm
