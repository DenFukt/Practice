#!/bin/bash

(sleep 2; exit 7) &

CHILD_PID=$!

echo "Запущено дочірній процес з PID: $CHILD_PID"
echo "Очікую завершення (близько 2 секунд)..."

wait $CHILD_PID
EXIT_CODE=$?

echo "Дочірній процес завершився з кодом: $EXIT_CODE"
