#!/bin/bash

cleanup() {
    echo -e "\nОтримано сигнал зупинки! Виконую очищення ресурсів (cleanup)..."
    sleep 1
    echo "Готово. Коректно завершую роботу."
    exit 0
}

trap cleanup SIGINT SIGTERM

echo "Процес $$ запущено. Натисніть Ctrl+C для graceful shutdown."

while true; do
    echo "tick=$(date +%s)"
    sleep 1
done
