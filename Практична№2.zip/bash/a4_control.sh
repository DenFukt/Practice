#!/bin/bash

echo "Запускаємо довгий процес (sleep 100) у фоні..."
sleep 100 &
PID=$!
echo "PID процесу: $PID"

echo -e "\n--- Стан ДО зупинки ---"
ps -p $PID -o pid,stat,comm

echo -e "\nНадсилаємо SIGSTOP (заморозити)..."
kill -STOP $PID
sleep 1

echo "--- Стан ПІСЛЯ SIGSTOP (очікуємо 'T' - Stopped) ---"
ps -p $PID -o pid,stat,comm

echo -e "\nНадсилаємо SIGCONT (розморозити)..."
kill -CONT $PID
sleep 1

echo "--- Стан ПІСЛЯ SIGCONT (очікуємо 'S' - Sleeping) ---"
ps -p $PID -o pid,stat,comm

echo -e "\nНадсилаємо SIGTERM (завершити)..."
kill -TERM $PID
sleep 1

echo "--- Перевірка після SIGTERM ---"
ps -p $PID -o pid,stat,comm || echo "Процес $PID успішно завершено і він зник з ps."
