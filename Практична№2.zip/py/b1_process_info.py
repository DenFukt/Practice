import os
import subprocess

pid = os.getpid()
ppid = os.getppid()

print(f"Мій PID: {pid}, Мій PPID: {ppid}")
print("-" * 30)

subprocess.run(["ps", "-p", str(pid), "-o", "pid,ppid,stat,ni,comm"])
