import os
import sys
import time

print(f"Батьківський процес (PID: {os.getpid()}) починає роботу...")
print("Робимо os.fork()...")

pid = os.fork()

if pid == 0:

    print(f"  [Дитина] Я народився! Мій PID: {os.getpid()}, мій батько: {os.getppid()}")
    print("  [Дитина] Виконую exec (замінюю себе на команду bash -c 'sleep 2; exit 7')...")

    os.execlp("bash", "bash", "-c", "sleep 2; exit 7")
else:
    print(f"[Батько] Я створив дитину з PID: {pid}. Чекаю її завершення (waitpid)...")
    child_pid, status = os.waitpid(pid, 0)
    if os.WIFEXITED(status):
        exit_code = os.WEXITSTATUS(status)
        print(f"[Батько] Дочірній процес {child_pid} завершився з кодом: {exit_code}")
