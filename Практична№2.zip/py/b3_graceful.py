import os
import signal
import time
import sys

stop_flag = False

def handle_signal(signum, frame):
    global stop_flag
    print(f"\nОтримано сигнал {signum}. Встановлюю прапорець зупинки...")
    stop_flag = True

signal.signal(signal.SIGINT, handle_signal)
signal.signal(signal.SIGTERM, handle_signal)

print(f"Процес {os.getpid()} працює. Натисніть Ctrl+C або надішліть SIGTERM.")

tick = 0
while not stop_flag:
    print(f"tick={tick}")
    tick += 1
    time.sleep(1)

print("Головний цикл перервано. Виконую cleanup...")
time.sleep(1)
print("Ресурси очищено. Коректне завершення.")
sys.exit(0)
