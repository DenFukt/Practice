import subprocess
import signal
import time

proc = subprocess.Popen(["sleep", "100"])
print(f"Запущено sleep 100 з PID: {proc.pid}")

time.sleep(1)
print("\nНадсилаю SIGSTOP...")
proc.send_signal(signal.SIGSTOP)

time.sleep(2)
print("\nНадсилаю SIGCONT...")
proc.send_signal(signal.SIGCONT)

time.sleep(1)
print("\nНадсилаю SIGTERM (через terminate())...")
proc.terminate()

proc.wait()
print(f"\nКод завершення (returncode): {proc.returncode}")
