import subprocess
import time

MAX_RESTARTS = 3

for attempt in range(1, MAX_RESTARTS + 1):
    print(f"\n[Supervisor] Запуск worker (спроба {attempt}/{MAX_RESTARTS})")
    
    proc = subprocess.Popen(["python3", "worker.py"])
    
    try:
        proc.wait()
    except KeyboardInterrupt:
        print("\n[Supervisor] Зупинка супервізора. Вбиваємо worker...")
        proc.terminate()
        proc.wait()
        break
        
    print(f"[Supervisor] Worker завершився з кодом {proc.returncode}.")
    
    if attempt < MAX_RESTARTS:
        print("[Supervisor] Перезапуск через 2 секунди...")
        time.sleep(2)

print("[Supervisor] Ліміт перезапусків вичерпано або роботу перервано.")
