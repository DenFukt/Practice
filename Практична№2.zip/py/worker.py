import signal
import time
import sys

stop = False

def handler(signum, frame):
    global stop
    stop = True

signal.signal(signal.SIGINT, handler)
signal.signal(signal.SIGTERM, handler)

tick = 0
while not stop:
    print(f"[Worker] tick={tick}")
    tick += 1
    time.sleep(1)

print("[Worker] Graceful shutdown...")
sys.exit(0)
